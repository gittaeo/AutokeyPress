package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"github.com/Alia5/VIIPER/internal/codegen/scanner"
)

func main() {
	projectRoot, err := os.Getwd()
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to get working directory: %v\n", err)
		os.Exit(1)
	}

	schemas, err := scanner.ScanDTOs(filepath.Join(projectRoot, "viiperclient", "structs.go"))
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to scan DTOs: %v\n", err)
		os.Exit(1)
	}

	output, err := json.MarshalIndent(schemas, "", "  ")
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to marshal JSON: %v\n", err)
		os.Exit(1)
	}

	fmt.Println(string(output))
}
