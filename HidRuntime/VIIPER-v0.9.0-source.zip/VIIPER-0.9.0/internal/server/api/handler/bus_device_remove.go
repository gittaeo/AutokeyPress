package handler

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"strconv"

	"github.com/Alia5/VIIPER/internal/server/api"
	"github.com/Alia5/VIIPER/internal/server/usb"
	"github.com/Alia5/VIIPER/viiperclient"
)

// BusDeviceRemove returns a handler that removes a device by device number.
func BusDeviceRemove(s *usb.Server) api.HandlerFunc {
	return func(req *api.Request, res *api.Response, logger *slog.Logger) error {
		idStr, ok := req.Params["id"]
		if !ok {
			return viiperclient.ErrBadRequest("missing id parameter")
		}
		busID, err := strconv.ParseUint(idStr, 10, 32)
		if err != nil {
			return viiperclient.ErrBadRequest(fmt.Sprintf("invalid busId: %v", err))
		}
		if req.Payload == "" {
			return viiperclient.ErrBadRequest("missing device number")
		}
		deviceID := req.Payload

		b := s.GetBus(uint32(busID))
		if b == nil {
			return viiperclient.ErrNotFound(fmt.Sprintf("bus %d not found", busID))
		}
		if err := s.RemoveDeviceByID(uint32(busID), deviceID); err != nil {
			return viiperclient.ErrNotFound(fmt.Sprintf("device %s not found on bus %d", deviceID, busID))
		}

		j, err := json.Marshal(viiperclient.DeviceRemoveResponse{BusID: uint32(busID), DevID: deviceID})
		if err != nil {
			return viiperclient.ErrInternal(fmt.Sprintf("failed to marshal response: %v", err))
		}
		res.JSON = string(j)
		return nil
	}
}
